document.getElementById("smart-text").innerHTML = "Smart text";

document.getElementById("content-text").style.color = "green";

function addText(id) {
    document.getElementById("learn-more-text").innerHTML = "Broj 1 po zadovoljstvu studenata!";
}

var spans = [];
spans[0] = "username-err";
spans[1] = "password-err";
spans[2] = "conf-password-err";
spans[3] = "email-err";
spans[4] = "conf-email-err";

function validateForm(x) {
    x.disabled = true;

    let inputs = [];
    inputs[0] = document.getElementById("username").value;
    inputs[1] = document.getElementById("password").value;
    inputs[2] = document.getElementById("conf-password").value;
    inputs[3] = document.getElementById("email").value;
    inputs[4] = document.getElementById("conf-email").value;

    const errors = [];
    errors[0] = "<span style='color: red;'>Unesite korisnicko ime!</span>";
    errors[1] = "<span style='color: red;'>Unesite lozinku!</span>";
    errors[2] = "<span style='color: red;'>Potvrdite lozinku!</span>";
    errors[3] = "<span style='color: red;'>Unesite email!</span>";
    errors[4] = "<span style='color: red;'>Potvrdite email!</span>";

    let count = 0;

    for (var i in inputs) {
        var errMessage = errors[i];
        var span = spans[i];
        if (inputs[i] === "" || inputs[i] === null) {
            document.getElementById(span).innerHTML = errMessage;
        } else {
            document.getElementById(span).innerHTML = "";
            count++;
        }
    }

    if (inputs[1] !== inputs[2]) {
        document.getElementById("conf-password-err").innerHTML = "Lozinke se ne poklapaju!";
        document.getElementById("conf-password-err").style.color = "red";
    } else {
        document.getElementById("conf-password-err").innerHTML = "";
        count += 1;
    }

    if (inputs[3] !== inputs[4]) {
        document.getElementById("conf-email-err").innerHTML = "Email se ne poklapa!";
        document.getElementById("conf-email-err").style.color = "red";
    } else {
        document.getElementById("conf-email-err").innerHTML = "";
        count += 1;
    }

    if (count === 7) {
        x.disabled = false;
        // document.getElementById("success").innerHTML = "<span style='color: green'>Uspesno ste popunili formu!</span>";
    } else {
        // document.getElementById("success").innerHTML = "";
    }
}