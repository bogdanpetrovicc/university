document.getElementById("plus").onclick = () => {
    var firstNum = parseInt(document.getElementById("first").value);
    var secondNum = parseInt(document.getElementById("second").value);
    var result = document.getElementById("result");

    result.value = firstNum + secondNum;
}

document.getElementById("minus").onclick = () => {
    var firstNum = parseInt(document.getElementById("first").value);
    var secondNum = parseInt(document.getElementById("second").value);
    var result = document.getElementById("result");

    result.value = firstNum - secondNum;
}

document.getElementById("multiply").onclick = () => {
    var firstNum = parseInt(document.getElementById("first").value);
    var secondNum = parseInt(document.getElementById("second").value);
    var result = document.getElementById("result");

    result.value = firstNum * secondNum;
}

document.getElementById("divide").onclick = () => {
    var firstNum = parseInt(document.getElementById("first").value);
    var secondNum = parseInt(document.getElementById("second").value);
    var result = document.getElementById("result");

    result.value = firstNum / secondNum;
}